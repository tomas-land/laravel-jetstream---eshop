<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <?php echo \Livewire\Livewire::styles(); ?>

    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
</head>

<body class="">


    
    <section class="container flex justify-center items-center text-3xl  bg-red-200 h-96">carousel</section>
    
    <section class="container my-16">
        <h1 class="text-3xl font-semibold text-gray-700 sm:pl-8">POPULIARIAUSIOS <br> PREKĖS</h1>
        <div class="border-t-2 my-8 border-gray-700 w-12"></div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product-component')->html();
} elseif ($_instance->childHasBeenRendered('5pSjt01')) {
    $componentId = $_instance->getRenderedChildComponentId('5pSjt01');
    $componentTag = $_instance->getRenderedChildComponentTagName('5pSjt01');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5pSjt01');
} else {
    $response = \Livewire\Livewire::mount('product-component');
    $html = $response->html();
    $_instance->logRenderedChild('5pSjt01', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </section>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.section-border','data' => []]); ?>
<?php $component->withName('jet-section-border'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    
    <div class="container grid grid-cols-4 gap-12 sm:grid-cols-1 sm:gap-6 lg:grid-cols-2 mx-auto">
        <div class="flex my-10 mx-auto sm:w-2/4 md:w-3/4 ">
            <div class="w-1/4  flex justify-end"><svg class="fill-current transition-to-gray"
                    xmlns="http://www.w3.org/2000/svg" width="44" height="44" viewBox="0 0 24 24">
                    <path class="hover:text-gray-200"
                        d="M20 8h-3V4H3c-1.1 0-2 .9-2 2v11h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-5l-3-4zM6 18.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm13.5-9l1.96 2.5H17V9.5h2.5zm-1.5 9c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z" />
                </svg></div>
            <div class="w-3/4 pl-6">
                <h4 class="font-semibold transition-to-gray">GREITAS PRISTATYMAS VISAME PASAULYJE</h4>
                <h5 class="text-sm mt-5 text-gray-400 ">Per 1-3 darbo dienas visoje Lietuvoje!</h5>
            </div>

        </div>
        <div class="flex my-10 mx-auto sm:w-2/4 md:w-2/4 ">
            <div class="w-1/4 flex justify-end"><svg class="fill-current transition-to-gray"
                    xmlns="http://www.w3.org/2000/svg" width="44" height="44" viewBox="0 0 24 24">
                    <path
                        d="M14 12c0-1.1-.9-2-2-2s-2 .9-2 2 .9 2 2 2 2-.9 2-2zm-2-9c-4.97 0-9 4.03-9 9H0l4 4 4-4H5c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.51 0-2.91-.49-4.06-1.3l-1.42 1.44C8.04 20.3 9.94 21 12 21c4.97 0 9-4.03 9-9s-4.03-9-9-9z" />
                </svg></div>
            <div class="w-3/4  pl-6">
                <h4 class="font-semibold transition-to-gray">NEMOKAMAS GRĄŽINIMAS</h4>
                <h5 class="text-sm mt-5 text-gray-400">14 dienų nemokamo grąžinimo garantija!</h5>
            </div>

        </div>
        <div class="flex my-10 mx-auto sm:w-2/4 md:w-2/4 ">
            <div class="w-1/4 flex justify-end"><svg class="fill-current transition-to-gray"
                    xmlns="http://www.w3.org/2000/svg" width="44" height="44"" viewBox=" 0 0 512 512">
                    <title>ionicons-v5-p</title>
                    <path
                        d="M435.25,48H312.35a14.46,14.46,0,0,0-10.2,4.2L56.45,297.9a28.85,28.85,0,0,0,0,40.7l117,117a28.85,28.85,0,0,0,40.7,0L459.75,210a14.46,14.46,0,0,0,4.2-10.2V76.8A28.66,28.66,0,0,0,435.25,48Z"
                        style="fill:none;stroke:#000;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px" />
                    <path d="M384,160a32,32,0,1,1,32-32A32,32,0,0,1,384,160Z" />
                </svg></div>
            <div class="w-3/4  pl-6">
                <h4 class="font-semibold transition-to-gray">SAUGUS ATSISKAITYMAS</h4>
                <h5 class="text-sm mt-5 text-gray-400">Naudojame saugių atsiskaitymų sprendimą!</h5>
            </div>

        </div>
        <div class="flex my-10 mx-auto sm:w-2/4 md:w-2/4 ">
            <div class="w-1/4 flex justify-end"><svg class="fill-current transition-to-gray"
                    xmlns="http://www.w3.org/2000/svg" width="44" height="44" viewBox="0 0 24 24">
                    <path
                        d="M14.36,14.23a3.76,3.76,0,0,1-4.72,0,1,1,0,0,0-1.28,1.54,5.68,5.68,0,0,0,7.28,0,1,1,0,1,0-1.28-1.54ZM9,11a1,1,0,1,0-1-1A1,1,0,0,0,9,11Zm6-2a1,1,0,1,0,1,1A1,1,0,0,0,15,9ZM12,2A10,10,0,1,0,22,12,10,10,0,0,0,12,2Zm0,18a8,8,0,1,1,8-8A8,8,0,0,1,12,20Z" />
                </svg></div>
            <div class="w-3/4  pl-6">
                <h4 class="font-semibold transition-to-gray">PAGALBA IR KONSULTACIJOS</h4>
                <h5 class="text-sm mt-5 text-gray-400">Telefonu I Internetu I El. paštu</h5>
            </div>

        </div>
    </div>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('button-component')->html();
} elseif ($_instance->childHasBeenRendered('L7hJEm1')) {
    $componentId = $_instance->getRenderedChildComponentId('L7hJEm1');
    $componentTag = $_instance->getRenderedChildComponentTagName('L7hJEm1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('L7hJEm1');
} else {
    $response = \Livewire\Livewire::mount('button-component');
    $html = $response->html();
    $_instance->logRenderedChild('L7hJEm1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.section-border','data' => []]); ?>
<?php $component->withName('jet-section-border'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    
    <section class="container my-16">
        <h1 class="text-3xl font-semibold text-gray-700 sm:pl-8">NAUJAUSIOS <br> PREKĖS</h1>
        <div class="border-t-2 my-8 border-gray-700 w-12"></div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product-component')->html();
} elseif ($_instance->childHasBeenRendered('k8Zec9O')) {
    $componentId = $_instance->getRenderedChildComponentId('k8Zec9O');
    $componentTag = $_instance->getRenderedChildComponentTagName('k8Zec9O');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('k8Zec9O');
} else {
    $response = \Livewire\Livewire::mount('product-component');
    $html = $response->html();
    $_instance->logRenderedChild('k8Zec9O', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </section>











    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>
<?php /**PATH C:\Program Files\Ampps\www\jetstream-livewire-eshop\resources\views/landing_page.blade.php ENDPATH**/ ?>