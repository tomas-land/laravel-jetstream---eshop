<div>
<button wire:click="setName('olof')">click me </button>
<input wire:model="name" type="text">
<?php echo e($name); ?>

</div>
<?php /**PATH C:\Program Files\Ampps\www\jetstream-livewire-eshop\resources\views/livewire/button-component.blade.php ENDPATH**/ ?>