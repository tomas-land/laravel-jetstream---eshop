<div>
    <div class="w-3/4 bg-gray-100 p-4">
        <div class="grid grid-cols-3 gap-3">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="">
                    <img src="./img/laptop.jpeg" class="" alt="laptop">
                    <h3 class="text-center uppercase"><?php echo e($product->name); ?></h3>
                    <h5 class="text-center uppercase">&euro;<?php echo e($product->price); ?></h5>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($products->links()); ?>



        </div>
</div>
<?php /**PATH C:\Program Files\Ampps\www\jetstream-livewire-eshop\resources\views/livewire/product-page-comp.blade.php ENDPATH**/ ?>