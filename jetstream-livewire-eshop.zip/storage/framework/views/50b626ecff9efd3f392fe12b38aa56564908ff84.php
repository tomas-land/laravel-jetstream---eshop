<div class="grid grid-cols-3 gap-12 sm:grid-cols-1"> 
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    
        <div class="">
            <img src="<?php echo e(asset('img/laptop.jpeg')); ?>" class="w-3/4 mx-auto" alt="laptop">
            <h3 class="text-center uppercase"><?php echo e($product->name); ?></h3>
            <h5 class="text-center uppercase">&euro;<?php echo e($product->price); ?></h5>
        </div>
       
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php /**PATH C:\Program Files\Ampps\www\jetstream-livewire-eshop\resources\views/livewire/product-component.blade.php ENDPATH**/ ?>