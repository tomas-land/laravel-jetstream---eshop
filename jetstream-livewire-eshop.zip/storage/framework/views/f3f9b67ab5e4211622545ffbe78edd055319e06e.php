<div class="flex text-base font-semibold border border-gray-300 ">
    <div class="text-gray-400 flex items-center justify-center mx-2">KIEKIS</div>
    <button class="px-4 p-4" wire:click="increment">+</button>
    <h1 class="flex items-center justify-center"><?php echo e($count); ?></h1>
    <input name='qty' type="hidden" value="<?php echo e($count); ?>">
    <button class="px-4 p-4" wire:click="decrement">-</button>
</div>
<?php /**PATH C:\Program Files\Ampps\www\jetstream-livewire-eshop\resources\views/livewire/counter.blade.php ENDPATH**/ ?>