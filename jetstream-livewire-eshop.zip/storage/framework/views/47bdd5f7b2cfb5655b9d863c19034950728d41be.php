<div class="sm:min-h-screen flex flex-col justify-center items-center pt-6 sm:pt-0 bg-gray-100">
    

    <div class="sm:w-full min-w-lg mt-6 px-6 py-4 bg-white shadow-md overflow-hidden rounded-lg">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\Program Files\Ampps\www\jetstream-livewire-eshop\resources\views/vendor/jetstream/components/authentication-card.blade.php ENDPATH**/ ?>