<div>
    <?php echo e($title); ?>

</div>
<?php /**PATH C:\Program Files\Ampps\www\jetstream-livewire-eshop\resources\views/livewire/product.blade.php ENDPATH**/ ?>