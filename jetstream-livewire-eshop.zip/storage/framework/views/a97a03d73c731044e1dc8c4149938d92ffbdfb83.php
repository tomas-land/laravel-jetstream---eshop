<div>

    

    <div class="container flex flex-wrap mt-8">
        
        <div class="image  w-2/4 sm:w-full">
            <img src="<?php echo e(asset($product->image)); ?>" class="" alt="laptop">
        </div>
        <div class="w-2/4 pl-6 sm:w-full sm:mt-12 sm:px-8">
            <div class="uppercase text-5xl"><?php echo e($product->name); ?></div>
            <div class="uppercase text-xl"><?php echo e($product->details); ?></div>
            <div class="text-lg mt-8"><?php echo e($product->price); ?> &euro;</div>
            <div class="text-lg mt-4 flex items-center"><svg xmlns="http://www.w3.org/2000/svg"
                    class="fill-current text-gray-400" width="12" height="12" viewBox="0 0 512 512">
                    <title>ionicons-v5-e</title>
                    <path
                        d="M394,480a16,16,0,0,1-9.39-3L256,383.76,127.39,477a16,16,0,0,1-24.55-18.08L153,310.35,23,221.2A16,16,0,0,1,32,192H192.38l48.4-148.95a16,16,0,0,1,30.44,0l48.4,149H480a16,16,0,0,1,9.05,29.2L359,310.35l50.13,148.53A16,16,0,0,1,394,480Z" />
                </svg><svg xmlns="http://www.w3.org/2000/svg" class="fill-current text-gray-400" width="12" height="12"
                    viewBox="0 0 512 512">
                    <title>ionicons-v5-e</title>
                    <path
                        d="M394,480a16,16,0,0,1-9.39-3L256,383.76,127.39,477a16,16,0,0,1-24.55-18.08L153,310.35,23,221.2A16,16,0,0,1,32,192H192.38l48.4-148.95a16,16,0,0,1,30.44,0l48.4,149H480a16,16,0,0,1,9.05,29.2L359,310.35l50.13,148.53A16,16,0,0,1,394,480Z" />
                </svg><svg xmlns="http://www.w3.org/2000/svg" class="fill-current text-gray-400" width="12" height="12"
                    viewBox="0 0 512 512">
                    <title>ionicons-v5-e</title>
                    <path
                        d="M394,480a16,16,0,0,1-9.39-3L256,383.76,127.39,477a16,16,0,0,1-24.55-18.08L153,310.35,23,221.2A16,16,0,0,1,32,192H192.38l48.4-148.95a16,16,0,0,1,30.44,0l48.4,149H480a16,16,0,0,1,9.05,29.2L359,310.35l50.13,148.53A16,16,0,0,1,394,480Z" />
                </svg><svg xmlns="http://www.w3.org/2000/svg" class="fill-current text-gray-400" width="12" height="12"
                    viewBox="0 0 512 512">
                    <title>ionicons-v5-e</title>
                    <path
                        d="M394,480a16,16,0,0,1-9.39-3L256,383.76,127.39,477a16,16,0,0,1-24.55-18.08L153,310.35,23,221.2A16,16,0,0,1,32,192H192.38l48.4-148.95a16,16,0,0,1,30.44,0l48.4,149H480a16,16,0,0,1,9.05,29.2L359,310.35l50.13,148.53A16,16,0,0,1,394,480Z" />
                </svg><svg xmlns="http://www.w3.org/2000/svg" class="fill-current text-gray-400" width="12" height="12"
                    viewBox="0 0 512 512">
                    <title>ionicons-v5-e</title>
                    <path
                        d="M394,480a16,16,0,0,1-9.39-3L256,383.76,127.39,477a16,16,0,0,1-24.55-18.08L153,310.35,23,221.2A16,16,0,0,1,32,192H192.38l48.4-148.95a16,16,0,0,1,30.44,0l48.4,149H480a16,16,0,0,1,9.05,29.2L359,310.35l50.13,148.53A16,16,0,0,1,394,480Z" />
                </svg>
                <div class="text-sm ml-3">( 3 atsiliepimai )</div>
            </div>
            <div class="mt-8"><?php echo e($product->description); ?></div>
            <div class="text-sm mt-5">Produkto kodas: 4986616197</div>
            <div class="text-sm ">Kategorija: <a
                    href="<?php echo e(route('shop')); ?>"><?php echo e($product->category['name']); ?></a>
            </div>
            <div class="my-5 text-lg">Liko <?php echo e($product->quantity); ?></div>
            <div class="flex">
                <div class="flex  text-base font-semibold border border-gray-300 ">
                    <div class="text-gray-400 flex items-center justify-center mx-2">KIEKIS</div>
                    <button class="px-4 p-4" wire:click="increment">+</button>
                    <h1 class="flex items-center justify-center"><?php echo e($count); ?></h1>
                    <button class="px-4 p-4" wire:click="decrement">-</button>
                </div>
                <form class="flex" action="" wire:submit.prevent="addToCart(<?php echo e($product->id); ?>)">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'ml-8']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'ml-8']); ?>į krepšelį <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </form>
            </div>
        </div>

        
        <div class="w-full mt-20">
            <section class="container my-16">
                <h1 class="text-3xl font-semibold text-gray-700 sm:pl-8">SUSIJUSIOS <br> PREKĖS</h1>
                <div class="border-t-2 my-8 border-gray-700 w-12"></div>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product-component',['products'=>$related_products])->html();
} elseif ($_instance->childHasBeenRendered('BszzXeJ')) {
    $componentId = $_instance->getRenderedChildComponentId('BszzXeJ');
    $componentTag = $_instance->getRenderedChildComponentTagName('BszzXeJ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BszzXeJ');
} else {
    $response = \Livewire\Livewire::mount('product-component',['products'=>$related_products]);
    $html = $response->html();
    $_instance->logRenderedChild('BszzXeJ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </section>
        </div>
    </div>

</div>
<?php /**PATH C:\Program Files\Ampps\www\jetstream-livewire-eshop\resources\views/livewire/pages/details-component.blade.php ENDPATH**/ ?>