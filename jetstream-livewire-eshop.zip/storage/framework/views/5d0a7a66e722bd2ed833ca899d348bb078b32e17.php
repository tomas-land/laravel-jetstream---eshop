<div>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-lg text-gray-800 leading-tight uppercase">
            <?php echo e(__('Krepšelis')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <?php if(Session::has('success_message')): ?>
        <div
            class="alert alert-success container my-5 border-green-200 border-solid border-2 py-5 text-center text-xl bg-green-100 text-green-700">
            <?php echo e(session('success_message')); ?>

        </div>

    <?php endif; ?>
    <?php if(Cart::count() == 0): ?>
        <div class="container my-5 border-gray-200 border-solid border-2 py-10 text-center text-2xl">Krepšelis tuščias
        </div>
    <?php else: ?>
        <div class="container flex flex-col mt-8">
            <div class="-my-2 overflow-x-auto -mx-6 lg:-mx-8">
                <div class="py-2 align-middle inline-block min-w-full px-6 lg:px-8">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="">
                            <tr>
                                <th scope="col"
                                    class="w-14 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                </th>
                                <th scope="col"
                                    class="w-32 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                </th>
                                <th scope="col"
                                    class="w-1/3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Produktas
                                </th>
                                <th scope="col"
                                    class=" py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Kaina
                                </th>
                                <th scope="col"
                                    class="w-1/3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Kiekis
                                </th>
                                <th scope="col"
                                    class="w py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Suma
                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                <tr>
                                    <td class="text-2xl text-gray-400 py-6 pr-6"><a href="#"
                                            wire:click="removeProduct('<?php echo e($product->rowId); ?>','<?php echo e($product->name); ?>')">×</a>
                                    </td>
                                    <td><img class="w-24 py-6" src="<?php echo e(asset('img/laptop.jpeg')); ?>" alt="">
                                    </td>
                                    <td><a
                                            href="<?php echo e(route('product.details', $product->model->slug)); ?>"><?php echo e($product->name); ?></a>
                                    </td>
                                    <td><?php echo e($product->price); ?> &euro;</td>
                                    <td>

                                        <div class="max-w-min flex text-base font-semibold border border-gray-300">
                                            <div class="text-gray-400 flex items-center justify-center mx-2">
                                                KIEKIS</div>
                                            <button class="px-4 p-4"
                                                wire:click="increaseQuantity('<?php echo e($product->rowId); ?>')">+</button>
                                            <h1 class="flex items-center justify-center"><?php echo e($product->qty); ?>

                                            </h1>
                                            
                                            <button class="px-4 p-4"
                                                wire:click="decreaseQuantity('<?php echo e($product->rowId); ?>')">-</button>
                                        </div>
                                    </td>
                                    <td><?php echo e($product->price * $product->qty); ?> &euro;</td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="w-full flex justify-end">
                    <div class=" mt-5 flex">
                        <ul class="text-right ">
                            <li>Iš viso už prekes : </li>
                            <li>PVM 21% mokestis : </li>
                            <li>Kompensacinis atlyginimas autoriams : </li>
                            <div class="w-full h-2 border-gray-400 border-solid"></div>
                            <li>Bendra suma :</li>
                        </ul>
                        <ul class="pl-4 text-right">
                            <li><?php echo e(Cart::subtotal() - Cart::tax()); ?> &euro;</li>
                            <li><?php echo e(Cart::tax()); ?> &euro;</li>
                            <li>10,50 &euro;</li>
                            <div class="w-full h-2 border-gray-400 border-solid"></div>
                            <li><?php echo e(Cart::initial()); ?> &euro;</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

<?php endif; ?>

<div class="text-center">
   <a href="<?php echo e(route('shop')); ?>">
       <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'uppercase my-20']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'uppercase my-20']); ?>Grįžti į parduotuvę <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
   </a>
</div>
</div>
<?php /**PATH C:\Program Files\Ampps\www\jetstream-livewire-eshop\resources\views/livewire/pages/cart-component.blade.php ENDPATH**/ ?>