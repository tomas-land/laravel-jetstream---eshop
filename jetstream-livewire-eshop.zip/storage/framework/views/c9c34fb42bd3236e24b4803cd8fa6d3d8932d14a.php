<div>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-lg text-gray-800 leading-tight uppercase">
            <?php echo e(__($category_name)); ?>

        </h2>
        <div class="breadcrumb flex items-center justify-center uppercase">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.nav-link','data' => ['href' => '/']]); ?>
<?php $component->withName('jet-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => '/']); ?>pradžia <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <svg xmlns="http://www.w3.org/2000/svg" class="fill-current text-gray-400" width="28" height="28"
                viewBox="0 0 48 48">
                <path d="M17.17 32.92l9.17-9.17-9.17-9.17L20 11.75l12 12-12 12z" />
            </svg>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.nav-link','data' => ['href' => ''.e(route('shop')).'']]); ?>
<?php $component->withName('jet-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('shop')).'']); ?>parduotuve <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <svg xmlns="http://www.w3.org/2000/svg" class="fill-current text-gray-400" width="28" height="28"
            viewBox="0 0 48 48">
            <path d="M17.17 32.92l9.17-9.17-9.17-9.17L20 11.75l12 12-12 12z" />
        </svg>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.nav-link','data' => ['href' => '']]); ?>
<?php $component->withName('jet-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => '']); ?><?php echo e($category_name); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>
    <div class="container flex h-screen">
        
        <div class="w-1/4 ">
            <h2 class="uppercase text-md font-semibold py-5">prekių kategorijos</h2>
            <ul class="flex-col  text-gray-400">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="">
                   <a href="<?php echo e(route('product.category',$category->slug)); ?>"><?php echo e($category->name); ?></a>
                   </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        
        <div class="w-3/4  px-4">
            <div class="flex justify-end mb-4">
                <div class=" ">
                    <select class="mr-4 py-4 pr-8 border-gray-300 text-gray-400 hover:text-gray-800" wire:model='pagesize'>
                        <option selected value="6">Rodyti po 6</option>
                        <option value="12">Rodyti po 12</option>
                        <option value="18">Rodyti po 18</option>
                    </select>
                    <select class="mr-4 p-4 border-gray-300 text-gray-400 hover:text-gray-800" wire:model='sorting'>
                        <option selected value="latest">Rikiuoti nuo naujausių</option>
                        <option value="min-max">Rikiuoti pagal kainą (min->max)</option>
                        <option value="max-min">Rikiuoti pagal kainą (max->min)</option>
                    </select>
                </div>
            </div>
            <div class="grid grid-cols-3 gap-3">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="">
                        <a href="<?php echo e(route('product.details', $product->slug)); ?>">
                            <img src="<?php echo e(asset($product->image)); ?>" class="" alt="product image">
                            <h3 class="text-center uppercase"><?php echo e($product->name); ?></h3>
                            <h5 class="text-center uppercase">&euro;<?php echo e($product->price); ?></h5>
                        </a>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
            <div class="mt-8">
                <?php echo e($products->links()); ?>

            </div>
        </div>

    </div>

</div>
<?php /**PATH C:\Program Files\Ampps\www\jetstream-livewire-eshop\resources\views/livewire/category-component.blade.php ENDPATH**/ ?>