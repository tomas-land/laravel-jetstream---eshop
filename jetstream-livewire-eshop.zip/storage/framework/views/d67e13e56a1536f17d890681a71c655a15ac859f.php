<div class="sm:hidden block">
    <div class="py-8">
        <div class="border-t-2 border-gray-200"></div>
    </div>
</div>
<?php /**PATH C:\Program Files\Ampps\www\jetstream-livewire-eshop\resources\views/vendor/jetstream/components/section-border.blade.php ENDPATH**/ ?>