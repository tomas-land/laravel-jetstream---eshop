<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'uppercase inline-flex items-center px-12 py-4 bg-gray-800 border border-transparent font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\Program Files\Ampps\www\jetstream-livewire-eshop\resources\views/vendor/jetstream/components/button.blade.php ENDPATH**/ ?>