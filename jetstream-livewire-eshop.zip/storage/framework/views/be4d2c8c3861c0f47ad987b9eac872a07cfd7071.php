<div>
  
</div>
<?php /**PATH C:\Program Files\Ampps\www\jetstream-livewire-eshop\resources\views/livewire/frontpage.blade.php ENDPATH**/ ?>