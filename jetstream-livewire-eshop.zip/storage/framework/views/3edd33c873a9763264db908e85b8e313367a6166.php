<div>
    <label class="relative block pr-8 ">
        
        <form action="<?php echo e(route('product.search')); ?>" method="GET">
            <span class="absolute inset-y-0 left-0 flex items-center pl-2">
                <button type="submit">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 512 512">
                        <title>ionicons-v5-f</title>
                        <path
                            d="M456.69,421.39,362.6,327.3a173.81,173.81,0,0,0,34.84-104.58C397.44,126.38,319.06,48,222.72,48S48,126.38,48,222.72s78.38,174.72,174.72,174.72A173.81,173.81,0,0,0,327.3,362.6l94.09,94.09a25,25,0,0,0,35.3-35.3ZM97.92,222.72a124.8,124.8,0,1,1,124.8,124.8A124.95,124.95,0,0,1,97.92,222.72Z" />
                    </svg>
                </button>
            </span>
            <input name="searchQuery" wire:model='query' wire:keydown.escape="resetSearch"
                class="focus:border-gray-300 focus:ring-0 outline-transparent form-input placeholder:italic placeholder:text-gray-400 block w-full border border-gray-300 rounded-md py-2 pl-9 pr-36 shadow-sm  "
                placeholder="Search for anything..." type="text"  autocomplete="off" />
        </form>
        <?php if(!empty($query)): ?>
            <div class="fixed top-0 right-0 bottom-0 left-0" wire:click='resetSearch'></div> <!-- div for closing search by clicking anywhere away from search-->
            <div class="absolute z-5 flex flex-col bg-white w-full divide-y border border-gray-200">
                <?php if(!empty($products)): ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="px-3 py-4 flex" href="<?php echo e(route('product.details', $product['slug'])); ?>">
                            <div class="w-14"><img src="<?php echo e(asset($product['image'])); ?>" alt=""></div>
                            <div class="flex flex-col pl-3">
                                <div class="text-lg font-bold"><?php echo e($product['name']); ?></div>
                                <div><?php echo e($product['details']); ?></div>
                            </div>
                            <div class="flex-grow flex justify-center items-center text-lg"><?php echo e($product['price']); ?>

                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="py-6 flex  bg-white w-full divide-y border border-gray-200 justify-center items-center">
                        Nieko nerasta</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    
    </label>
</div>
<?php /**PATH C:\Program Files\Ampps\www\jetstream-livewire-eshop\resources\views/livewire/header-search-component.blade.php ENDPATH**/ ?>