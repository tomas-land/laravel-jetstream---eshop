<div>
<button wire:click="setName('olof')">click me </button>
<input wire:model="name" type="text">
{{$name}}
</div>
