<x-guest-layout>
    shopas
 
 </x-guest-layout>
 
 